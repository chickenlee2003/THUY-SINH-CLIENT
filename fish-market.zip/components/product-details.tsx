'use client';

import { useState } from 'react';
import { useCart } from '@/lib/cart/cartContext'; // Import CartContext
import { Star, HelpCircle, Heart, BarChart2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ProductDetailsProps {
  id: string;
  name: string;
  reviews: number;
  shippingDays: number;
  seller: string;
  priceRange: {
    min: number;
    max: number;
  };
  stock: number;
}

export function ProductDetails({
  id,
  name,
  reviews,
  shippingDays,
  seller,
  priceRange,
  stock,
}: ProductDetailsProps) {
  const { dispatch } = useCart(); // Access CartContext
  const [size, setSize] = useState<'Small' | 'Medium' | 'Large'>('Small');
  const [quantity, setQuantity] = useState(1);

  const price =
    size === 'Small'
      ? priceRange.min
      : size === 'Medium'
      ? (priceRange.min + priceRange.max) / 2
      : priceRange.max;

  const totalPrice = price * quantity;

  const handleAddToCart = () => {
    dispatch({
      type: 'ADD_TO_CART',
      payload: {
        id,
        name,
        price,
        size,
        quantity,
        image: '/placeholder.svg', // Replace with the actual image URL
      },
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">{name}</h1>
        <div className="mt-2 flex items-center gap-2">
          <div className="flex">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className="h-4 w-4 text-gray-300" />
            ))}
          </div>
          <span className="text-sm text-gray-500">({reviews} reviews)</span>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500">Estimate Shipping Time:</span>
          <span>{shippingDays} Days</span>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" className="gap-2">
            <HelpCircle className="h-4 w-4" />
            Product Inquiry
          </Button>
          <Button variant="outline" size="sm" className="gap-2">
            <Heart className="h-4 w-4" />
            Add to wishlist
          </Button>
          <Button variant="outline" size="sm" className="gap-2">
            <BarChart2 className="h-4 w-4" />
            Add to compare
          </Button>
        </div>

        <div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">Sold by</span>
            <span>{seller}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">Price</span>
            <span className="text-teal-600">
              ₹{priceRange.min} - ₹{priceRange.max}/Pc
            </span>
          </div>
        </div>

        <div className="space-y-2">
          <span className="text-sm text-gray-500">Size</span>
          <div className="flex gap-2">
            {['Small', 'Medium', 'Large'].map((option) => (
              <Button
                key={option}
                variant={size === option ? 'default' : 'outline'}
                onClick={() => setSize(option as typeof size)}
                className="px-6"
              >
                {option}
              </Button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <span className="text-sm text-gray-500">Quantity</span>
          <div className="flex items-center gap-4">
            <div className="flex items-center">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="rounded-r-none"
              >
                -
              </Button>
              <div className="w-20 border-y px-4 py-2 text-center">{quantity}</div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.min(stock, quantity + 1))}
                className="rounded-l-none"
              >
                +
              </Button>
            </div>
            <span className="text-sm text-gray-500">({stock} available)</span>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-500">Total Price</span>
            <span className="text-xl font-bold text-teal-600">
              ₹{totalPrice.toFixed(2)}
            </span>
          </div>
          <div className="mt-4 flex gap-4">
            <Button className="flex-1" onClick={handleAddToCart}>
              Add to cart
            </Button>
            <Button variant="secondary" className="flex-1">
              Buy Now
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <span className="text-sm text-gray-500">Share</span>
          <div className="flex gap-2">
            {['email', 'twitter', 'facebook', 'linkedin', 'whatsapp'].map(
              (platform) => (
                <Button
                  key={platform}
                  variant="outline"
                  size="icon"
                  className="rounded-full"
                >
                  <span className="sr-only">Share on {platform}</span>
                  <i className={`icon-${platform}`} />
                </Button>
              )
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
