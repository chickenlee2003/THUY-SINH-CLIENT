'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { X } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'

interface AddToCartModalProps {
  isOpen: boolean
  onClose: () => void
  product: {
    id: string
    name: string
    image: string
    price: number | { min: number; max: number }
    stock: number
    sizes?: string[]
  }
}

export function AddToCartModal({ isOpen, onClose, product }: AddToCartModalProps) {
  const [selectedSize, setSelectedSize] = useState<string>()
  const [quantity, setQuantity] = useState(30)
  const [currentPrice, setCurrentPrice] = useState(0)
  const [totalPrice, setTotalPrice] = useState(0)

  // Handle price calculation based on size and quantity
  useEffect(() => {
    let price = 0
    if (typeof product.price === 'number') {
      price = product.price
    } else {
      if (selectedSize === 'Small') price = product.price.min
      else if (selectedSize === 'Medium') price = (product.price.min + product.price.max) / 2
      else if (selectedSize === 'Large') price = product.price.max
      else price = product.price.min
    }
    setCurrentPrice(price)
    setTotalPrice(price * quantity)
  }, [product.price, selectedSize, quantity])

  // Reset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setQuantity(30)
      setSelectedSize(product.sizes?.[0])
    }
  }, [isOpen, product.sizes])

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>{product.name}</span>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 rounded-full"
              onClick={onClose}
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-6">
          <div className="flex gap-4">
            <div className="relative h-24 w-24 rounded-lg border overflow-hidden">
              <Image
                src={product.image}
                alt={product.name}
                fill
                className="object-cover"
              />
            </div>
            <div className="flex-1 space-y-4">
              <div>
                <div className="text-sm text-gray-500">Price</div>
                {typeof product.price === 'number' ? (
                  <div className="text-teal-600">₹{product.price.toFixed(2)} /Pc</div>
                ) : (
                  <div className="text-teal-600">
                    ₹{product.price.min.toFixed(2)} - ₹{product.price.max.toFixed(2)} /Pc
                  </div>
                )}
              </div>

              {product.sizes && (
                <div className="space-y-2">
                  <div className="text-sm text-gray-500">Size</div>
                  <div className="flex gap-2">
                    {product.sizes.map((size) => (
                      <Button
                        key={size}
                        variant={selectedSize === size ? 'default' : 'outline'}
                        onClick={() => setSelectedSize(size)}
                        className="h-8"
                      >
                        {size}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">Quantity</span>
              <span className="text-sm text-gray-500">({product.stock} available)</span>
            </div>
            <div className="flex items-center">
              <Button
                variant="outline"
                size="icon"
                className="rounded-r-none"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
              >
                -
              </Button>
              <div className="w-20 border-y px-4 py-2 text-center">
                {quantity}
              </div>
              <Button
                variant="outline"
                size="icon"
                className="rounded-l-none"
                onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
              >
                +
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between border-t pt-4">
              <span className="text-sm text-gray-500">Total Price</span>
              <span className="text-xl font-bold text-teal-600">₹{totalPrice.toFixed(2)}</span>
            </div>
            <Button 
              className="w-full" 
              size="lg"
              onClick={() => {
                // Add to cart logic here
                onClose()
              }}
            >
              Add to cart
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

