'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { Cookie, Package, Container, Fish, Fan, Filter, Wrench } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Category {
  id: string;
  name: string;
  icon: React.ElementType;
  subcategories?: Omit<Category, 'subcategories'>[];
}

const categories: Category[] = [
  {
    id: 'fish-food',
    name: 'Fish Food',
    icon: Cookie,
  },
  {
    id: 'fresh-water-fish',
    name: 'Fresh Water Fish',
    icon: Package,
    subcategories: [
      {
        id: 'betta-fish',
        name: 'Betta Fish',
        icon: Fan,
      },
      {
        id: 'crowntail',
        name: 'Crowntail',
        icon: Filter,
      },
    ],
  },
  {
    id: 'aquarium-tanks',
    name: 'Aquarium Tanks',
    icon: Container,
    subcategories: [
      {
        id: 'tank-maintenance',
        name: 'Tank Maintenance Services',
        icon: Wrench,
      },
    ],
  },
  {
    id: 'exotic-fishes',
    name: 'Exotic Fishes',
    icon: Fish,
  },
];

export function CategoryList() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const handleCategoryClick = (categoryId: string) => {
    const params = new URLSearchParams(searchParams);
    params.set('category', categoryId);
    router.push(`/products?${params.toString()}`);
  };

  return (
    <div className="space-y-8">
      {categories.map((category) => (
        <div key={category.id} className="space-y-4">
          <button
            onClick={() => handleCategoryClick(category.id)}
            className={cn(
              'flex w-full items-center gap-4 rounded-lg border p-4 hover:border-teal-600 hover:text-teal-600'
            )}
          >
            <category.icon className="h-12 w-12" />
            <span className="text-xl font-medium">{category.name}</span>
          </button>

          {category.subcategories && (
            <div className="ml-16 grid gap-2">
              {category.subcategories.map((subcategory) => (
                <button
                  key={subcategory.id}
                  onClick={() => handleCategoryClick(subcategory.id)}
                  className={cn(
                    'flex w-full items-center gap-4 rounded-lg p-2 hover:text-teal-600'
                  )}
                >
                  <subcategory.icon className="h-5 w-5" />
                  <span>{subcategory.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
