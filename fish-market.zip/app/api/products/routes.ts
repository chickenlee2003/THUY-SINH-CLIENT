import { NextResponse } from 'next/server'

// This would typically come from your database
const products = [
  {
    id: '1',
    name: 'Betta Fish Female',
    price: 100.00,
    image: '/placeholder.svg',
    categoryId: 'betta-fish',
    stock: 100
  },
  {
    id: '2',
    name: 'Plakat Betta fish',
    price: 200.00,
    image: '/placeholder.svg',
    categoryId: 'plakat',
    stock: 150
  },
  {
    id: '3',
    name: 'Full moon Betta fish Female',
    price: 200.00,
    image: '/placeholder.svg',
    categoryId: 'fullmoon',
    stock: 80
  },
  {
    id: '4',
    name: 'Crown Tail betta fish Male',
    price: 200.00,
    image: '/placeholder.svg',
    categoryId: 'crowntail',
    stock: 120
  },
  {
    id: '5',
    name: 'King Cobra Crown Tail betta fish',
    price: 240.00,
    image: '/placeholder.svg',
    categoryId: 'crowntail',
    stock: 90
  },
  {
    id: '6',
    name: 'DoubleTail Fullmoon Betta Fish',
    price: 190.00,
    image: '/placeholder.svg',
    categoryId: 'doubletail',
    stock: 110
  },
  {
    id: '7',
    name: 'Boxer Plakat Betta fish',
    price: 190.00,
    image: '/placeholder.svg',
    categoryId: 'plakat',
    stock: 130
  }
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const category = searchParams.get('category')
  
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500))

  if (category === 'all' || !category) {
    return NextResponse.json(products)
  }

  const filteredProducts = products.filter(
    product => product.categoryId === category
  )

  return NextResponse.json(filteredProducts)
}

