import Link from 'next/link'
import { ChevronRight } from 'lucide-react'
import { ProductImageGallery } from '@/components/product-image-gallery'
import { ProductDetails } from '@/components/product-details'
import { ProductReviews } from '@/components/product-reviews'

// This would typically come from an API or database
const products = {
  '1': {
    id: '1',
    name: 'Gold',
    images: [
      {
        id: '1',
        url: '/placeholder.svg',
        alt: 'Gold fish swimming'
      },
      {
        id: '2',
        url: '/placeholder.svg',
        alt: 'Gold fish side view'
      }
    ],
    reviews: [],
    shippingDays: 3,
    seller: 'SK Aquarium',
    priceRange: {
      min: 9,
      max: 35
    },
    stock: 680,
    description: "The Gold Fish is a beautiful freshwater fish known for its vibrant orange coloration and peaceful nature. These fish are perfect for beginners and make excellent additions to community tanks. They are relatively easy to care for and can adapt to a variety of water conditions.",
  }
}

interface ProductPageProps {
  params: {
    id: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const product = products[params.id]

  if (!product) {
    return <div>Product not found</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6 flex items-center gap-2 text-sm">
        <Link href="/" className="hover:text-teal-600">
          Home
        </Link>
        <ChevronRight className="h-4 w-4" />
        <span>{product.name}</span>
      </div>
      
      <div className="grid gap-8 md:grid-cols-2">
        <ProductImageGallery images={product.images} />
        <ProductDetails {...product} />
      </div>

      <ProductReviews 
        productId={product.id}
        reviews={product.reviews}
        description={product.description}
      />
    </div>
  )
}

